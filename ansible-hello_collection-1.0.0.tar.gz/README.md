# hello_collection
hello world example of ansible collection
